package http://mcodeinitiative.org/codex/us/icare/ImplementationGuide/mcodeinitiative.icare-0.1.2;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class ExpectedPerformanceTime {

}
