package http://hl7.org/fhir/us/fhirURL/ImplementationGuide/1;

import org.hl7.fhir.r4.model.ProfilingWrapper;

public class CancerGeneticMarkerAnalysisResult {

}
