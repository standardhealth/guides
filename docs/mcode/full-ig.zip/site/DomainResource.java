package http://hl7.org/fhir/us/shr/ImplementationGuide/1;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class DomainResource {

}
