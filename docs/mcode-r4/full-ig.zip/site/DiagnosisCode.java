package http://hl7.org/fhir/us/mcode/ImplementationGuide/hl7.fhir.us.mcode-0.9.1;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class DiagnosisCode {

}
