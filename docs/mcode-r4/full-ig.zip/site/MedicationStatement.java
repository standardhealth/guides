package http://hl7.org/fhir/us/odh/ImplementationGuide/hl7.fhir.us.odh-1.1.0;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class MedicationStatement {

}
