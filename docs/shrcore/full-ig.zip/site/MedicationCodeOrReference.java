package http://hl7.org/fhir/us/obf/ImplementationGuide/obf-0.8.0;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class MedicationCodeOrReference {

}
