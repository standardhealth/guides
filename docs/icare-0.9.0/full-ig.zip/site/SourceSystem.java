package http://mcodeinitiative.org/us/icare/ImplementationGuide/mcodeinitiative.icare-0.1.0;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class SourceSystem {

}
